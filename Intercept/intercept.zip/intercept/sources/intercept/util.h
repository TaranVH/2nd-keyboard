#pragma once

char SelectOption(const char *text, const char *options);
char *ReadText(const char *query);
